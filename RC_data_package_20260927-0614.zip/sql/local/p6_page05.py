#!/usr/bin/env python3
"""P6: write 05_取数手册与常见坑.md. Timing / payload numbers are read from results/ at generation time, so the page
always matches the final result files (re-run after any new query)."""
import os
import sys
import pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from metrics import T  # noqa: E402

PKG = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
R = os.path.join(PKG, "results")
rd = lambda n: pd.read_csv(os.path.join(R, n))
t = rd("timing.csv")
t16 = t[t.batch == 16]
ps = rd("p1_payload_size.csv").groupby("scene_id").sum(numeric_only=True).loc["LKUS_push"]
rl = rd("_runlog.csv")
slow = int((t.seconds > 3).sum())
L = ["# 05 取数手册与常见坑", "",
     "> 2026-09-27 编写，依据本包与前两个包的实测。对象：`aws-luckyus-iriskcontrolservice-rw` / `luckyus_iriskcontrolservice.t_access_log_0000…0063`（LKUS_push 为主）。",
     "> 工具与模板见 `toolkit/README.md`；字段见 `dictionary/t_access_log_0000.md`。", "",
     "## 1. 基本口径", "", "| 项 | 口径 | 依据 |", "|---|---|---|",
     "| 时间 | `create_time` 是 UTC；纽约日边界用 `toolkit/ny_day_bounds.py` 算，窗口内不能跨夏令时切换（下一次 2026-11-01） | `results/p1_freshness.csv`、`results/p0_server_vars.csv` |",
     "| 时间谓词 | 永远写 `create_time >= 'UTC' AND create_time < 'UTC'`，不要在 WHERE 里给 `create_time` 套函数；走索引 `idx_create_time_sharding_key` | `results/explain/` |",
     "| 最终结果 | `result` 列 = `response.$.result`（返回调用方的结果）；引擎自己的结果在 `$.re.resultName`，两者会不同（引擎 REVIEW → 最终 PASS，DR-016） | `results/p1_result_sources_summary.csv` |",
     "| 短信 / 邮件 | 源库没有 `l2_scene`；`$.para.email` 非空为邮件候选，为空或不存在为短信（DR-002）。Grafana 巡检大盘用 Doris 的 `l2_scene='1001'` | `results/p1_chk_consistency.csv`、`results/p0_grafana_patrol_panels.md` |",
     "| 区号 | `country_code` 列与 `$.para.countryCode` 都带 `+`；统计时 `TRIM(LEADING '+' FROM x)` 后比较 | `results/p1_chk_consistency.csv` |",
     "| IP 地理 | 基础列 `ip_city/ip_province/country/city` 全空；用 `$.para.realIpCountry/realIpProvince/realIpCity` | `results/p1_scene_rows.csv` |",
     "| 去重手机号（LKUS_push） | `sharding_key` = 带 `+` 的完整手机号；同一窗口、同一分组内各分片 `COUNT(DISTINCT sharding_key)` 可相加；其它场景的分片键不同（DR-021） | DR-014、DR-021 |",
     "| V3 分数 | 按**形状**取：任一 reCAPTCHA 特征的 `comments.apiResp` 是含 `riskAnalysis.score` 的 JSON 对象 | DR-005、`results/p3_v3_fid_daily.csv` |",
     "| cid | 105 Android / 106 iOS / 108 H5 / 702 自助机（`request.$.cidOriginEnum` = `SELF_SERVICE_MACHINE_US`） | `results/p1_cid_app_summary.csv` |",
     "| App 版本 | 按数值比较：major×1000000 + minor×1000 + patch（文本比较时 `'1.4.9' > '1.4.30'`） | `toolkit/tk09_engine_vs_final.sql` |", "",
     "## 2. JSON 路径", "", "| 需要的值 | 取法 |", "|---|---|",
     "| 请求参数对象 | `CAST(JSON_UNQUOTE(JSON_EXTRACT(request_strategy_engine, '$.para')) AS JSON)`（`$.para` 是**字符串**） |",
     "| 在线 / 预上线命中数组 | `CAST(JSON_UNQUOTE(JSON_EXTRACT(response_strategy_engine, '$.re.hitStrategy')) AS JSON)`（同样是字符串）；`hitPreOnlineStrategy`、`hitBreakStrategy` 同理 |",
     "| 命中元素字段 | `strategyId, strategyName, strategyType, status (ONLINE/PREONLINE), resultName, execPriority, vaild` |",
     "| 特征数组 | `JSON_EXTRACT(response_strategy_engine, '$.re.featureDetail')`（原生数组）；元素 `featureId, name, type, code, result, comments.apiResp` |",
     "| 规则数组 | `JSON_EXTRACT(response_strategy_engine, '$.re.ruleDetail')`（原生数组）；元素 `ruleId, name, type, code, result, comments` |",
     "| 单个特征值 | `JSON_TABLE(JSON_EXTRACT(resp,'$.re.featureDetail'), '$[*]' COLUMNS (fid VARCHAR(64) PATH '$.featureId', code VARCHAR(64) PATH '$.code', v VARCHAR(64) PATH '$.comments.apiResp'))` + `WHERE fid = 'feature_…'` |",
     "| 某策略是否命中 | `JSON_CONTAINS(<命中数组>, JSON_OBJECT('strategyId', 'strategy_…'))` |",
     "| token 状态 | `JSON_EXTRACT(pa,'$.recaptchaV3Token') IS NULL` → 不存在；`= ''` → 为空；只取状态，**不取值** |",
     "| 分片键比较 | `CAST(sharding_key AS BINARY) = CAST(<候选> AS BINARY)`（只输出计数，不取值；排序规则不同时用 BINARY） |", "",
     "## 3. 批量与速度（主库口径）", "",
     f"- 聚合语句：每条 ≤1 个纽约日、≤16 个分片（UNION ALL，每个分支各带时间谓词），带 `/*+ MAX_EXECUTION_TIME(10000) */`。行级抽取：每条 ≤1 小时，结果只留本机 `_local_only/`。",
     f"- 实测（`results/timing.csv`，本包共 {len(t):,} 条分片语句，经执行器 {len(rl):,} 次运行，`results/_runlog.csv`）：16 分片语句 {len(t16):,} 条，中位数 {t16.seconds.median():.2f} s、95 分位 {t16.seconds.quantile(.95):.2f} s、最长 {t16.seconds.max():.2f} s、超过 3 s 的 {int((t16.seconds > 3).sum())} 条；全部语句中位数 {t.seconds.median():.2f} s、最长 {t.seconds.max():.2f} s、超过 3 s 的 {slow} 条（执行器随即把批量减半）；无超时。",
     "- 最重的写法是逐元素展开 `featureDetail`（DR-003 逐日返回码、E1 抽取）；只看 LKUS_push、只取需要的标量时，16 分片 × 1 天通常 <1 s。",
     f"- 每行 LKUS_push 平均：`response_strategy_engine` {ps.bytes_response_engine / ps.n:,.0f} B，其中 `featureDetail` {ps.bytes_feature_detail / ps.n:,.0f} B、`ruleDetail` {ps.bytes_rule_detail / ps.n:,.0f} B（纽约日 2026-09-26，`results/p1_payload_size.csv`）。**永远不要 SELECT 整个 JSON 列**。", "",
     "## 4. 团队手册里的五个坑（仍然成立）", "",
     "1. **不要 SELECT 整个 featureDetail / 任何整列 JSON**：在服务端用 `JSON_TABLE`/`JSON_EXTRACT` 只取标量。",
     "2. **特征名会变，按 featureId 取**；分数还要按形状取（同一个分数在不同日期挂在不同 featureId 上，DR-005）。",
     "3. **可能合并请求的 GROUP BY 要带每请求唯一键（`id`）**，或者用派生表先逐行计算、再聚合。",
     "4. **网关拒绝含 `REPLACE(` 的 SELECT**：去 `+` 用 `TRIM(LEADING '+' FROM x)`。",
     "5. **Doris `LATERAL VIEW` 是内连接**：featureDetail 为空的行会消失（Doris 不可达，本次未复测）。", "",
     "## 5. 实测新坑（2026-09-25 / 09-26 / 09-27）", "",
     "1. **`JSON_TABLE` 的第一个参数不能直接是派生表里的表达式列**（报 1210）：包一层 `JSON_EXTRACT(l.col, '$')`。",
     "2. **在线与预上线命中要分两段 `JSON_TABLE` 再 UNION ALL**：一个 `JSON_TABLE` 套 `NESTED PATH` 会丢元素。",
     "3. **排序规则不一致**：`JSON_UNQUOTE(...)` 与表列直接比较报 1267 → `CAST(a AS BINARY) = CAST(b AS BINARY)`；UNION 各分支排序规则不同报 1271 → `CONVERT(x USING utf8mb4) COLLATE utf8mb4_0900_ai_ci`。",
     "4. **`COUNT(DISTINCT)` 不能跨分组、跨窗口相加**：同一手机号同一天可能既 PASS 又 REJECT；多天去重只能用行级抽取（加盐哈希）在本地算——聚合语句每条 ≤1 天，逐日去重数不能相加。",
     "5. **uid 不是分片键**：LKUS_push 的 uid 会跨分片（`results/p3_dr014_shard_spread.csv`），按分片相加会高估。",
     "6. **`USER_PRIVILEGES` 会返回全实例账号的权限**：按 `CURRENT_USER()` 过滤，且不要取 `GRANTEE` 列。",
     "7. **配置里的名称也可能带个人信息**：按手机号精确匹配的规则会把号码写进规则名与策略名；导出时名称列也要整值屏蔽（`02` §1）。",
     "8. **操作日志 `t_operation_log` 的 `updateTime` 是 13 位毫秒时间戳**：`FROM_UNIXTIME(x/1000)`；`operation_time` 列本身是 UTC。",
     "9. **`CONDITION_MISS` 不等于没有值**：`PARAMS_ERROR` / `DIMENSION_EMPTY` 才是没有值——引用它的策略会长期 0 命中，看起来像「没流量」（DR-003 / DR-004）。",
     "10. **`conditions: [\"\"]` 是界面的空占位，不是条件**：判断累计特征是否带条件要看 `hasCondition` 与非空条件字符串（`sql/local/p3_params.py`）。",
     "11. **时刻类规则按 UTC 比较**：配置里的 `02:00`、`09:00` 都是 UTC（DR-018）。",
     "12. **优先级高的 PASS 命中后引擎不再执行其它策略**：统计「同时命中」时，PASS 与更低优先级的 REJECT 不会同时出现（DR-001）。",
     f"13. **upush 按日统计表的日期列**：{T['upush_date']}；与风控日志关联只按 UTC 日，不能按纽约日。",
     "14. **分片键因场景而异**：push / register / captcha 按完整手机号，login / payment / 下单 / 取消 / 新人券按 `userNo`（DR-014 常设抽查）。按分片相加的去重数只对该场景的分片键成立。",
     "15. **列别名不能用 MySQL 保留字或内建函数名**：2026-09-26 `DATE(create_time) AS utc_date` 在 EXPLAIN 阶段报 1064；执行器现在按 `information_schema.KEYWORDS`（RESERVED=1）实时检查别名（`results/p0_reserved_words.csv`）。",
     "16. **安静时段的 EXPLAIN 门槛**：窗口里 0000 分片没有行时，EXPLAIN 只返回「No matching min/max row」（没有扫描），执行器的门槛会拒绝。放宽窗口让它走索引，不要绕过门槛（2026-09-27 新鲜度检查，见 `RUN_LOG.md`）。",
     "17. **跨月的逐日聚合从 8 分片起步**：每行都要 CAST `$.para` 的聚合比计时测试重；2026-09-26 的 31 / 33 天聚合在 16 分片时超过 3 s，被减到 4 分片。",
     "18. **PASS 类预上线策略的额外召回**：取最终结果不是 PASS 的命中（它上线后会改成 PASS 的请求），不是它的全部命中（`toolkit/tk03_extra_recall.sql` 参数 `pass_class`）。",
     "19. **「某策略唯一拦截」要看其它在线 REJECT 类命中**：同一请求上可能有多条 REJECT 命中，只有在没有其它 REJECT 类命中时才算这一条的「唯一拦截」；去掉它后的结果按其它命中推算（可能是 PASS 也可能是 REVIEW，假设其它策略判定不变），这是计数，不是因果（`toolkit/tk10_unique_reject.sql`，DR-027）。", "",
     "## 6. 取数前检查清单", "",
     "- 时间窗口换算成 UTC 了吗？跨夏令时了吗？",
     "- 是否只取需要的 JSON 标量？有没有任何个人信息字段（手机号、邮箱、uid、userNo、IP、设备号、token）的值被 SELECT？",
     "- 语句过了 `shard_runner.py check` 吗？（单条语句、执行时限提示紧跟第一个 SELECT、时间谓词是原列 + 字面量）",
     "- 先在 0000 分片 EXPLAIN 一次，是 `range` 吗？",
     "- 去重是窗口级算的吗？有没有跨分组 / 跨窗口相加？",
     "- 分数、特征是按形状 / featureId 取的吗，有没有按名称？",
     "- 版本号是按数值比较的吗？"]
open(os.path.join(PKG, "05_取数手册与常见坑.md"), "w", encoding="utf-8").write("\n".join(L) + "\n")
print("05 written", len(L), "statements", len(t))
