-- name: p1_keys_para
-- server: aws-luckyus-iriskcontrolservice-rw (via MCP server mcp-db-gateway)
-- purpose: P1: JSON/column structure, all scenes, NY 2026-09-26 (keys and presence counts only)
-- kind: agg; shards: 64 (0000..0063); batch: 16; windows: 1 [2026-09-26 04:00:00 .. 2026-09-27 04:00:00) UTC, chunk=day
-- params: {}
-- merge: rows from every shard/window are concatenated; aggregate locally (sum counts)
-- run (NY): 2026-09-27 06:24

SELECT /*+ MAX_EXECUTION_TIME(10000) */ '{shard}' AS shard, l.scene_id, k.k AS json_key, COUNT(*) AS n_rows
FROM (SELECT scene_id, CASE WHEN JSON_TYPE(JSON_EXTRACT(request_strategy_engine, '$.para')) = 'STRING' AND JSON_VALID(JSON_UNQUOTE(JSON_EXTRACT(request_strategy_engine, '$.para'))) THEN CAST(JSON_UNQUOTE(JSON_EXTRACT(request_strategy_engine, '$.para')) AS JSON) ELSE JSON_EXTRACT(request_strategy_engine, '$.para') END AS j
      FROM luckyus_iriskcontrolservice.{tbl}
      WHERE create_time >= '{utc_start}' AND create_time < '{utc_end}' AND JSON_VALID(request_strategy_engine)) l,
  JSON_TABLE(JSON_KEYS(l.j), '$[*]' COLUMNS (k VARCHAR(128) PATH '$')) k
GROUP BY l.scene_id, k.k
