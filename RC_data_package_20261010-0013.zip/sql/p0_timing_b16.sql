-- name: p0_timing_b16
-- server: aws-luckyus-iriskcontrolservice-rw (via MCP server mcp-db-gateway)
-- purpose: P0: timing test, featureDetail codes on NY 2026-10-09, shards 0000-0015, batch 16
-- kind: agg; shards: 16 (0000..0015); batch: 16; windows: 1 [2026-10-09 04:00:00 .. 2026-10-10 04:00:00) UTC, chunk=day
-- params: {}
-- merge: rows from every shard/window are concatenated; aggregate locally (sum counts)
-- run (NY): 2026-10-10 00:17

SELECT /*+ MAX_EXECUTION_TIME(10000) */ '{shard}' AS shard, f.featureId, f.code, COUNT(*) AS n,
  SUM(f.v IS NULL OR f.v = '') AS empty_value
FROM luckyus_iriskcontrolservice.{tbl} l,
  JSON_TABLE(JSON_EXTRACT(l.response_strategy_engine, '$.re.featureDetail'), '$[*]'
    COLUMNS (featureId VARCHAR(64) PATH '$.featureId', code VARCHAR(64) PATH '$.code',
             v VARCHAR(64) PATH '$.comments.apiResp')) f
WHERE l.create_time >= '{utc_start}' AND l.create_time < '{utc_end}' AND l.scene_id = 'LKUS_push'
GROUP BY f.featureId, f.code
